/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
var linkToParent = {9:-1,0:-1,12:-1,13:-1,2:-1,5:-1,1:-1,11:-1};
