var keywords=[{w:"Complete",p:["p0"]},{w:"Owner\'s",p:["p0","p1"]},{w:"Manual",p:["p0"]},{w:"in",p:["p0"]},{w:"the",p:["p0","p12"]},{w:"center",p:["p0"]},{w:"display",p:["p0"]},{w:"information",p:["p1"]},{w:"Seat",p:["p2"]},{w:"belts",p:["p2"]},{w:"Context",p:["p3"]},{w:"Sensitive",p:["p3"]},{w:"Help",p:["p3"]},{w:"All-wheel",p:["p4"]},{w:"drive",p:["p4"]},{w:"specific",p:["p4"]},{w:"Glossary",p:["p5"]},{w:"ID",p:["p6","p8","p10"]},{w:"Volvo",p:["p7","p8","p10"]},{w:"cars",p:["p7"]},{w:"app",p:["p7"]},{w:"Towing",p:["p9"]},{w:"capacity",p:["p9"]},{w:"and",p:["p9"]},{w:"tongue",p:["p9"]},{w:"weight",p:["p9"]},{w:"How",p:["p10","p11","p12"]},{w:"to",p:["p10","p11","p12"]},{w:"create",p:["p10"]},{w:"a",p:["p10"]},{w:"get",p:["p11"]},{w:"started",p:["p11"]},{w:"with",p:["p11"]},{w:"Google",p:["p11"]},{w:"services",p:["p11"]},{w:"view",p:["p12"]},{w:"Vehicle",p:["p12"]},{w:"Identification",p:["p12"]},{w:"Number",p:["p12"]},{w:"(VIN)",p:["p12"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3, 4, 5, 6];
ph["p1"]=[1, 7];
ph["p2"]=[8, 9];
ph["p3"]=[10, 11, 12];
ph["p4"]=[13, 14, 15];
ph["p5"]=[16];
ph["p6"]=[17];
ph["p7"]=[18, 19, 20];
ph["p8"]=[18, 17];
ph["p9"]=[21, 22, 23, 24, 25];
ph["p10"]=[26, 27, 28, 29, 18, 17];
ph["p12"]=[26, 27, 35, 4, 36, 37, 38, 39];
ph["p11"]=[26, 27, 30, 31, 32, 33, 34];
var keywordsInfo = {
    keywords: keywords,
    ph: ph
}
